﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ValidateWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            bool isValid =true;
            foreach (Control c in errorProvider.ContainerControl.Controls)
                if (c.Text=="" || (errorProvider.GetError(c) != "" && errorProvider.GetError(c) != "valid"))
                {
                    isValid = false;
                    break;
               
                }
            if (isValid)
            {
                MessageBox.Show("form is valid.");
            }
            else
            {
                MessageBox.Show("form is not valid.");
            }

        }
        /// <summary>
        /// validate alphabet with space
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
           Match match = Regex.Match(txtName.Text, @"^[a-zA-Z][a-zA-Z ]*$",RegexOptions.IgnoreCase);
            if (!match.Success)
            {          
               
                successProvider.SetError(txtName, "");
                errorProvider.SetError(txtName, "provided name is not valid.");
                
            }
            else
            {
                errorProvider.SetError(txtName, "");
                successProvider.SetError(txtName, "valid");
            }
        }
        /// <summary>
        /// validate age having numbers 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtAge_Validating(object sender, CancelEventArgs e)
        {
            Match match = Regex.Match(txtAge.Text, @"^[0-9]*[1-9][0-9]*$", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                
                successProvider.SetError(txtAge, "");
                errorProvider.SetError(txtAge, "provided age is not valid.");
            }
            else
            {
                errorProvider.SetError(txtAge, "");
                successProvider.SetError(txtAge, "valid");
            }
        }
        /// <summary>
        /// validate email id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            Match match = Regex.Match(txtEmail.Text, @"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
                
                successProvider.SetError(txtEmail, "");
                errorProvider.SetError(txtEmail, "provided email address in not valid.");
            }
            else
            {
                errorProvider.SetError(txtEmail, "");
                successProvider.SetError(txtEmail, "valid");
            }

        }
        /// <summary>
        /// validate 11 digit number
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtContact_Validating(object sender, CancelEventArgs e)
        {
            Match match = Regex.Match(txtContact.Text, @"^[0-9]{11,11}$", RegexOptions.IgnoreCase);
            if (!match.Success)
            {
              
                successProvider.SetError(txtContact, "");
                errorProvider.SetError(txtContact, "provided contact is not valid.");
            }
            else
            {
                errorProvider.SetError(txtContact,"");
                successProvider.SetError(txtContact, "valid");
            }

        }
    }
}
